/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menuDados;

import dados.*;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author alen
 */
public class FXMLMenuController implements Initializable {
    
    private static int jugador1PointsS = 500;
    private static int jugador2PointsS = 500;
    
    @FXML
    private Label jugador1Points;
    
    @FXML
    private Label jugador2Points;
    
    @FXML
    private TextField field1;
    
    @FXML
    private TextField field2;
    
    @FXML
    private ImageView jugador1Verde;
    
    @FXML
    private ImageView jugador2Verde;
    
    @FXML
    private Pane paneAbajo;
    
    @FXML
    private Pane paneArriba;
    
    @FXML
    public void txtNumbers_OnKeyTyped(KeyEvent event) throws Exception {

        if (!event.getCharacter().matches("[0-9]")) {
            event.consume();
        }
    }
    
    @FXML
    public void txtNumbers_Comprobar(KeyEvent event) throws Exception {
        int campo1 = Integer.parseInt(field1.getText());
        int campo2 = Integer.parseInt(field2.getText());
        
        if(campo1<=0 && campo1>20){
            //event.consume();
        }
        
        if(campo2<=0 && campo2>20){
            //event.consume();
        }
    }
    
    
    public void txtNumbers_Comprobar2(KeyEvent event) throws Exception {
        int campo1 = Integer.parseInt(field1.getText());
        int campo2 = Integer.parseInt(field2.getText());
        
        if(!field1.equals("") && !field2.equals("")){
            TimeUnit.SECONDS.sleep(1);
            System.out.println("Empieza");
            
            Image verde = new Image(getClass().getResource("/Resources/verde.png").toString());
            jugador1Verde.setImage(verde);
            
            int random = (int)(Math.random()*1+6);
            System.out.println(random);
            
            jugador1Verde.setImage(verde);
            //jugador1Verde.setImage(null);
            TimeUnit.SECONDS.sleep(3);
            
            random = (int)(Math.random()*1+6);
            System.out.println(random);
            jugador2Verde.setImage(verde);
        }
        
        
       
        
        
//        while(campo1>0 && campo1<=20){
//            event.consume();
//        }
        
        
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        
        
    }    
     
}
