/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author alen
 */
public class FXMLDocumentController implements Initializable {
    
    
    private static int numeroCumple=16;
    
    @FXML
    private ImageView fotoDado;
    
    @FXML 
    private Label os;
    
    @FXML
    private Label date;
    
    @FXML
    private Label user;
    
    @FXML
    private Button button1;
    
    @FXML 
    private void MenuDado(ActionEvent event){
         try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/menuDados/FXMLMenu.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
    }
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
       //SistemaOperativo();
       //Tiempo();
       //Username();
         
         
 
        
        
    }    
 
    
    public void SistemaOperativo(){
       
    
       String SistemaOperativo= System.getProperty("os.name");
       os.setText(SistemaOperativo);
    }
    
    public void Tiempo(){
     
    LocalDate currentdDate7 =  LocalDate.now();
    LocalDate currentDatePlus7 = currentdDate7.plusDays(numeroCumple);
    
    DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
        final Timeline timeline = new Timeline(
                new KeyFrame(
                        Duration.millis(500),
                        event -> {
                            date.setText(currentDatePlus7.toString() + " " + timeFormat.format(System.currentTimeMillis()));
                            //date.setText(currentDatePlus7.toString());
                        })
        );
        timeline.setCycleCount(Animation.INDEFINITE);

        timeline.play();
    }
    
    
    public void Username(){
     String username= System.getProperty("user.name");
     user.setText(username);
    }
    
    
    public void Tiempo2() throws ParseException{
    
   


    }
    
}
